import cv2,numpy as np,json
from pathlib import Path
P=Path('/workspace/work/product-refine');fs=np.load(P/'frames.npz');r={int(k):np.float32(q) for k,q in json.load(open(P/'tracks.json')).items()};a=1152;q=r[a].copy();g=cv2.cvtColor(fs[str(a)],cv2.COLOR_BGR2GRAY);mask=np.zeros_like(g);cv2.fillConvexPoly(mask,q.astype(int),255);mask=cv2.erode(mask,np.ones((20,20),np.uint8));pts=cv2.goodFeaturesToTrack(g,250,.002,4,mask=mask)
for i in range(a+1,1163):
 ng=cv2.cvtColor(fs[str(i)],cv2.COLOR_BGR2GRAY);new,st,err=cv2.calcOpticalFlowPyrLK(g,ng,pts,None,winSize=(41,41),maxLevel=4);good=(st.ravel()==1)&(err.ravel()<60)
 if good.sum()<8:break
 M,ins=cv2.estimateAffinePartial2D(pts[good],new[good],method=cv2.RANSAC,ransacReprojThreshold=2.0)
 if M is None or ins.sum()<8:break
 q=cv2.transform(q[None],M)[0];r[i]=q.copy();pts=new[good][ins.ravel()==1].reshape(-1,1,2);g=ng
 print(i,len(pts),q[0].tolist())
(P/'tracks.json').write_text(json.dumps({i:q.tolist() for i,q in r.items()}))
