# Citable product-panel refinement

Rebuilt the Hues overview and Arabian competitor panels as animated HTML/SVG in Hyperframes 0.9.15. The seven modern website cards and the remainder of the polished video remain in the base cut.

Data transcribed from the supplied product screenshots:
- Hues: 66.7% AI share of voice; 8 of 12 answers cited; 40 sources; 12 prompts. Perplexity is the engine shown in the supplied breakdown. Dining is cited; spacious suites and wellness/spa are not mentioned.
- Arabian: XVA Art Hotel and The Dubai EDITION each 25.0%, 3 mentions; Arabian Courtyard, The Heritage Hotel, Hotel Boulevard and Al Seef each 16.7%.
- The projects are separate examples. Browser chrome, email and RankAI branding are excluded.

Animation retained/rebuilt: tracked screen entrance and perspective; staggered metric reveals and count-ups; growing citation ring; prompt-row reveals; cursor movement and 35.545-second click highlight; cross-slide between projects; staggered competitor bars and numerical counters; growing radar polygon; matched exit movement, defocus and opacity.

The Hyperframes timeline starts at global time 33.1 seconds. The overlay affects frames 1002–1160 at 30 fps (33.4–38.667 s). The source is a flat MP4, so internal animation and the heavily blurred exit are reconstructed, not recovered from an editable original. Original panel trajectories are fitted to decoded boundaries; earliest clipped frames use optical flow. The final MP4 is encoded continuously for player compatibility. The existing AAC audio stream is copied unchanged.

The included Hyperframes project renders the editable animated panel surfaces. Tracking and compositing scripts are also provided; their BASE/input paths point to the current workspace and can be adjusted to the downloaded prior MP4.
