import cv2,numpy as np,json
from pathlib import Path
P=Path('/workspace/work/product-refine');cap=cv2.VideoCapture('/workspace/work/website-swap/citable-modern-websites-fixed.mp4');cap.set(cv2.CAP_PROP_POS_FRAMES,995);frames={}
for i in range(995,1166):
 ok,f=cap.read();assert ok;frames[i]=f
np.savez_compressed(P/'frames.npz',**{str(i):f for i,f in frames.items()})
qs={}
def intersect(a,b):
 v,p=a;w,q=b;A=np.column_stack([v,-w]); t=np.linalg.solve(A,q-p)[0];return p+t*v
for i,f in frames.items():
 mask=(np.max(f,axis=2)<100).astype(np.uint8);mask[:,:420]=0
 cnts,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
 if not cnts:continue
 c=max(cnts,key=cv2.contourArea)
 if cv2.contourArea(c)<45000:continue
 poly=cv2.approxPolyDP(c,.025*cv2.arcLength(c,True),True)[:,0,:]
 if len(poly)!=4:continue
 poly=poly[np.argsort(np.arctan2(poly[:,1]-poly[:,1].mean(),poly[:,0]-poly[:,0].mean()))]
 # start top left; angles sort makes TL first for these cards
 pts=c[:,0,:].astype(float);lines=[]
 for j in range(4):
  a=poly[j];b=poly[(j+1)%4];d=b-a;t=((pts-a)@d)/(d@d);cross=np.abs((d[0]*(pts-a)[:,1]-d[1]*(pts-a)[:,0]))/np.linalg.norm(d)
  choose=(t>.07)&(t<.93)&(cross<15)
  if choose.sum()<8:break
  vx,vy,x,y=cv2.fitLine(pts[choose].astype(np.float32),cv2.DIST_HUBER,0,.001,.001).ravel();lines.append((np.array([vx,vy]),np.array([x,y])))
 if len(lines)!=4:continue
 q=np.array([intersect(lines[(j-1)%4],lines[j]) for j in range(4)])
 if q[:,0].max()>1277:continue
 qs[i]=q
print('contour frames',min(qs),max(qs),len(qs))
# Optical flow backward through clipped entrance using the first fully visible card.
a=min(qs);q=qs[a];mask=np.zeros((720,1280),np.uint8);cv2.fillConvexPoly(mask,q.astype(int),255);mask=cv2.erode(mask,np.ones((15,15),np.uint8));gray={i:cv2.cvtColor(f,cv2.COLOR_BGR2GRAY) for i,f in frames.items()}
pts=cv2.goodFeaturesToTrack(gray[a],250,.006,4,mask=mask);prev=a
for i in range(a-1,994,-1):
 new,st,err=cv2.calcOpticalFlowPyrLK(gray[prev],gray[i],pts,None,winSize=(41,41),maxLevel=4)
 good=(st.ravel()==1)&(err.ravel()<40);aa=pts[good];bb=new[good]
 if len(aa)<6:break
 H,inl=cv2.findHomography(aa,bb,cv2.RANSAC,1.8)
 if H is None or inl.sum()<6:break
 q=cv2.perspectiveTransform(q.astype(np.float32)[None],H)[0];qs[i]=q
 pts=bb[inl.ravel()==1].reshape(-1,1,2);prev=i
 print('entry',i,len(pts),flush=True)
# Inspect geometry.
(P/'tracks.json').write_text(json.dumps({i:q.tolist() for i,q in qs.items()}))
ims=[]
for i in range(998,1165,5):
 f=frames[i].copy()
 if i in qs:cv2.polylines(f,[qs[i].astype(int)],True,(0,255,0),2)
 cv2.putText(f,f'{i} {i/30:.2f}',(20,30),0,1,(0,0,255),2);ims.append(cv2.resize(f,(426,240)))
while len(ims)%4:ims.append(np.zeros_like(ims[0]))
cv2.imwrite(str(P/'tracked.jpg'),np.vstack([np.hstack(ims[j:j+4]) for j in range(0,len(ims),4)]))
