import cv2,numpy as np,json,subprocess
from scipy.signal import savgol_filter
from pathlib import Path
P=Path('/workspace/work/product-refine');(P/'previews').mkdir(exist_ok=True)
BASE='/workspace/work/website-swap/citable-modern-websites-fixed.mp4'
tracks={int(k):np.float32(v) for k,v in json.load(open(P/'tracks.json')).items()};fs=np.load(P/'frames.npz')
for j,dx in [(1156,32),(1157,60),(1158,83),(1159,98),(1160,108)]:tracks[j]=tracks[1155]+[dx,0]
ix=list(range(1015,1151)); smooth=savgol_filter(np.array([tracks[i] for i in ix]),5,2,axis=0)
for i,q in zip(ix,smooth):tracks[i]=q
src=np.float32([[0,0],[1199,0],[1199,799],[0,799]])
ref=1147;H=cv2.getPerspectiveTransform(tracks[ref].astype(np.float32),src)
old=cv2.warpPerspective(fs[str(ref)],H,(1200,800)).astype(np.float32)
mask=np.zeros((800,1200),np.float32);r=28
cv2.rectangle(mask,(r,0),(1199-r,799),1,-1);cv2.rectangle(mask,(0,r),(1199,799-r),1,-1)
for x,y in [(r,r),(1199-r,r),(1199-r,799-r),(r,799-r)]:cv2.circle(mask,(x,y),r,1,-1)
mask=cv2.GaussianBlur(mask,(0,0),.55)
textures=[];c=cv2.VideoCapture(str(P/'panels.mp4'))
while True:
 ok,im=c.read()
 if not ok:break
 textures.append(im.astype(np.float32))
print('textures',len(textures),flush=True)
alphaLog={};bg=fs['1165'].astype(np.float32)
def overlay(fr,i):
 if i not in tracks:return fr
 q=tracks[i].astype(np.float32);H=cv2.getPerspectiveTransform(src,q);tex=textures[i-993]
 m=cv2.warpPerspective(mask,H,(1280,720));new=cv2.warpPerspective(tex*mask[:,:,None],H,(1280,720))
 if i<1151:
  # Slight filtering matches the surface softness of the supplied MP4.
  sigma=.4 if i>1010 else .7
  new=cv2.GaussianBlur(new,(0,0),sigma);m=cv2.GaussianBlur(m,(0,0),sigma)
  out=fr*(1-m[:,:,None])+new
 else:
  coords=np.float32([[u,v] for u in [380,560,740] for v in [650,710,750]])
  dst=cv2.perspectiveTransform(coords[None],H)[0];vals=[]
  for (u,v),(x,y) in zip(coords,dst):
   x,y=int(x),int(y)
   if x<5 or x>=1275 or y<5 or y>=715:continue
   obs=np.median(fr[y-3:y+4,x-3:x+4].reshape(-1,3),axis=0);back=np.median(bg[y-3:y+4,x-3:x+4].reshape(-1,3),axis=0);base=old[int(v),int(u)]
   vals.extend(((back-obs)/np.maximum(back-base,1)).tolist())
  opacity=float(np.clip(np.median(vals),0,1));alphaLog[i]=opacity
  delta=(tex-old)*mask[:,:,None];delta=cv2.warpPerspective(delta,H,(1280,720))
  sigma={1151:.4,1152:.6,1153:.9,1154:1.5,1155:2.7,1156:4.2,1157:6,1158:8,1159:10,1160:12}[i]
  delta=cv2.GaussianBlur(delta,(0,0),sigma)
  out=fr.astype(np.float32)+delta*opacity
 return np.clip(out,0,255).astype(np.uint8)
cap=cv2.VideoCapture(BASE)
cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','bgr24','-s','1280x720','-r','30','-i','-','-i',BASE,'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','slow','-crf','17','-profile:v','high','-level:v','3.1','-pix_fmt','yuv420p','-g','60','-c:a','copy','-movflags','+faststart',str(P/'citable-refined-product.mp4')]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for i in range(1395):
 ok,fr=cap.read();assert ok
 out=overlay(fr,i)
 if i in [1002,1006,1015,1027,1040,1053,1068,1074,1085,1093,1098,1105,1117,1131,1147,1153,1155,1157,1159,1160]:cv2.imwrite(str(P/'previews'/f'{i}.jpg'),out)
 p.stdin.write(out.tobytes())
 if i%150==0:print('frame',i,flush=True)
p.stdin.close();assert p.wait()==0
(P/'fade-audit.json').write_text(json.dumps(alphaLog,indent=2));print('fade',alphaLog,flush=True)
